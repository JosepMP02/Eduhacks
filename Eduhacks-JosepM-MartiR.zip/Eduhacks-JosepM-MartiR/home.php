<?php
  session_start();
  if(!isset($_SESSION['username']) && !isset($_COOKIE['usuario'])){
    header("Location: index.php?redirected=3");
  }
?>
<!doctype html>
<html lang="en"> 
  <head>
  	<title>EduHaks</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet" href="css/cssPropio.css">

    <link rel="stylesheet" href="css/style.css">

  </head>
  <body class="img js-fullheight" style="background-image: url(images/bg.jpg);">
    <h1 style="text-align:center;" class="heading-section">Benvenuti <?php echo $_COOKIE['usuario']?></h1>
    <a href="./php/logout.php">Logout</a>
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>

